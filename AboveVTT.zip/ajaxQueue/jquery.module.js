// jquery.module.js
import '../jquery-3.6.0.min.js'
export default window.jQuery.noConflict(true)
