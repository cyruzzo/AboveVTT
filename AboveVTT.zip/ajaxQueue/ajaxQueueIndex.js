import { ajaxQueue } from "./ajaxQueue.js";
window.ajaxQueue = ajaxQueue;
