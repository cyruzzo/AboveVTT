/** Changes to this file will be overwritten by .github/workflows/release-build.yml
 * If you need to change this file, make sure you update .github/workflows/release-build.yml as well */
const AVTT_ENVIRONMENT = {
  "versionSuffix": "-local",
  "baseUrl": "https://services.abovevtt.net"
};